<?php

use Illuminate\Support\Facades\Route;

Route::get('/', 'AppController@index');
